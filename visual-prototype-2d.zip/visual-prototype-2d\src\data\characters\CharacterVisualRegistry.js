﻿/**
 * CharacterVisualRegistry.js
 * 
 * Canonical registry mapping classId -> visual profile -> character assets -> animation set -> weapon profile.
 * Zero string heuristics. Direct implementation of Section 1, 2, 5, 11, 20.
 */

import { CLASS_IDENTITIES } from '../classes/ClassIdentity.js';
import { CLASS_WEAPON_MAP } from './WeaponRegistry.js';

export const CHARACTER_VISUAL_REGISTRY = {
  // 1. Human Fighter
  human_fighter: {
    classId: 'human_fighter',
    visualProfile: 'human_fighter',
    animationSet: 'anim_human_fighter',
    weaponProfile: 'sword',
    name: 'Human Fighter',
    race: 'Human',
    gender: 'm',
    archetype: 'fighter',
    assets: {
      master: 'public/assets/characters/human/fighter/master.png',
      idle: 'public/assets/characters/human/fighter/idle.png',
      attack: 'public/assets/characters/human/fighter/attack.png',
      cast: 'public/assets/characters/human/fighter/cast.png',
      hit: 'public/assets/characters/human/fighter/hit.png',
      death: 'public/assets/characters/human/fighter/death.png',
      ultimate: 'public/assets/characters/human/fighter/ultimate.png',
      staticPortrait: 'public/assets/characters/human/fighter/master.png'
    },
    metrics: { frameWidth: 128, frameHeight: 128, scale: 2.2, originX: 0.5, originY: 0.85 }
  },

  // 2. Human Sorcerer
  human_sorcerer: {
    classId: 'human_sorcerer',
    visualProfile: 'human_sorcerer',
    animationSet: 'anim_human_sorcerer',
    weaponProfile: 'staff',
    name: 'Human Sorcerer',
    race: 'Human',
    gender: 'm',
    archetype: 'mage',
    assets: {
      master: 'public/assets/characters/human/sorcerer/master.png',
      idle: 'public/assets/characters/human/sorcerer/idle.png',
      attack: 'public/assets/characters/human/sorcerer/attack.png',
      cast: 'public/assets/characters/human/sorcerer/cast.png',
      hit: 'public/assets/characters/human/sorcerer/hit.png',
      death: 'public/assets/characters/human/sorcerer/death.png',
      ultimate: 'public/assets/characters/human/sorcerer/ultimate.png',
      staticPortrait: 'public/assets/characters/human/sorcerer/master.png'
    },
    metrics: { frameWidth: 128, frameHeight: 128, scale: 2.2, originX: 0.5, originY: 0.85 }
  },

  // 3. Elf Fighter
  elf_fighter: {
    classId: 'elf_fighter',
    visualProfile: 'elf_fighter',
    animationSet: 'anim_elf_fighter',
    weaponProfile: 'light_blade',
    name: 'Elf Fighter',
    race: 'Elf',
    gender: 'f',
    archetype: 'fighter',
    assets: {
      master: 'public/assets/characters/elf/fighter/master.png',
      idle: 'public/assets/characters/elf/fighter/idle.png',
      attack: 'public/assets/characters/elf/fighter/attack.png',
      cast: 'public/assets/characters/elf/fighter/cast.png',
      hit: 'public/assets/characters/elf/fighter/hit.png',
      death: 'public/assets/characters/elf/fighter/death.png',
      ultimate: 'public/assets/characters/elf/fighter/ultimate.png',
      staticPortrait: 'public/assets/characters/elf/fighter/master.png'
    },
    metrics: { frameWidth: 128, frameHeight: 128, scale: 2.2, originX: 0.5, originY: 0.85 }
  },

  // 4. Elf Mage
  elf_mage: {
    classId: 'elf_mage',
    visualProfile: 'elf_mage',
    animationSet: 'anim_elf_mage',
    weaponProfile: 'staff',
    name: 'Elf Mage',
    race: 'Elf',
    gender: 'f',
    archetype: 'mage',
    assets: {
      master: 'public/assets/characters/elf/mage/master.png',
      idle: 'public/assets/characters/elf/mage/idle.png',
      attack: 'public/assets/characters/elf/mage/attack.png',
      cast: 'public/assets/characters/elf/mage/cast.png',
      hit: 'public/assets/characters/elf/mage/hit.png',
      death: 'public/assets/characters/elf/mage/death.png',
      ultimate: 'public/assets/characters/elf/mage/ultimate.png',
      staticPortrait: 'public/assets/characters/elf/mage/master.png'
    },
    metrics: { frameWidth: 128, frameHeight: 128, scale: 2.2, originX: 0.5, originY: 0.85 }
  },

  // 5. Dark Elf Fighter
  dark_elf_fighter: {
    classId: 'dark_elf_fighter',
    visualProfile: 'dark_elf_fighter',
    animationSet: 'anim_dark_elf_fighter',
    weaponProfile: 'light_blade',
    name: 'Dark Elf Fighter',
    race: 'Dark Elf',
    gender: 'm',
    archetype: 'fighter',
    assets: {
      master: 'public/assets/characters/dark-elf/fighter/master.png',
      idle: 'public/assets/characters/dark-elf/fighter/idle.png',
      attack: 'public/assets/characters/dark-elf/fighter/attack.png',
      cast: 'public/assets/characters/dark-elf/fighter/cast.png',
      hit: 'public/assets/characters/dark-elf/fighter/hit.png',
      death: 'public/assets/characters/dark-elf/fighter/death.png',
      ultimate: 'public/assets/characters/dark-elf/fighter/ultimate.png',
      staticPortrait: 'public/assets/characters/dark-elf/fighter/master.png'
    },
    metrics: { frameWidth: 128, frameHeight: 128, scale: 2.2, originX: 0.5, originY: 0.85 }
  },

  // 6. Dark Elf Mage
  dark_elf_mage: {
    classId: 'dark_elf_mage',
    visualProfile: 'dark_elf_mage',
    animationSet: 'anim_dark_elf_mage',
    weaponProfile: 'staff',
    name: 'Dark Elf Mage',
    race: 'Dark Elf',
    gender: 'm',
    archetype: 'mage',
    assets: {
      master: 'public/assets/characters/dark-elf/mage/master.png',
      idle: 'public/assets/characters/dark-elf/mage/idle.png',
      attack: 'public/assets/characters/dark-elf/mage/attack.png',
      cast: 'public/assets/characters/dark-elf/mage/cast.png',
      hit: 'public/assets/characters/dark-elf/mage/hit.png',
      death: 'public/assets/characters/dark-elf/mage/death.png',
      ultimate: 'public/assets/characters/dark-elf/mage/ultimate.png',
      staticPortrait: 'public/assets/characters/dark-elf/mage/master.png'
    },
    metrics: { frameWidth: 128, frameHeight: 128, scale: 2.2, originX: 0.5, originY: 0.85 }
  },

  // 7. Orc Fighter
  orc_fighter: {
    classId: 'orc_fighter',
    visualProfile: 'orc_fighter',
    animationSet: 'anim_orc_fighter',
    weaponProfile: 'heavy_weapon',
    name: 'Orc Fighter',
    race: 'Orc',
    gender: 'm',
    archetype: 'fighter',
    assets: {
      master: 'public/assets/characters/orc/fighter/master.png',
      idle: 'public/assets/characters/orc/fighter/idle.png',
      attack: 'public/assets/characters/orc/fighter/attack.png',
      cast: 'public/assets/characters/orc/fighter/cast.png',
      hit: 'public/assets/characters/orc/fighter/hit.png',
      death: 'public/assets/characters/orc/fighter/death.png',
      ultimate: 'public/assets/characters/orc/fighter/ultimate.png',
      staticPortrait: 'public/assets/characters/orc/fighter/master.png'
    },
    metrics: { frameWidth: 128, frameHeight: 128, scale: 2.35, originX: 0.5, originY: 0.85 }
  },

  // 8. Orc Shaman
  orc_shaman: {
    classId: 'orc_shaman',
    visualProfile: 'orc_shaman',
    animationSet: 'anim_orc_shaman',
    weaponProfile: 'ritual_staff',
    name: 'Orc Shaman',
    race: 'Orc',
    gender: 'm',
    archetype: 'mage',
    assets: {
      master: 'public/assets/characters/orc/shaman/master.png',
      idle: 'public/assets/characters/orc/shaman/idle.png',
      attack: 'public/assets/characters/orc/shaman/attack.png',
      cast: 'public/assets/characters/orc/shaman/cast.png',
      hit: 'public/assets/characters/orc/shaman/hit.png',
      death: 'public/assets/characters/orc/shaman/death.png',
      ultimate: 'public/assets/characters/orc/shaman/ultimate.png',
      staticPortrait: 'public/assets/characters/orc/shaman/master.png'
    },
    metrics: { frameWidth: 128, frameHeight: 128, scale: 2.3, originX: 0.5, originY: 0.85 }
  },

  // Monster: Shadow Wraith
  shadow_wraith: {
    classId: 'shadow_wraith',
    visualProfile: 'shadow_wraith',
    animationSet: 'anim_shadow_wraith',
    weaponProfile: 'scythe',
    name: 'Shadow Wraith',
    race: 'Undead',
    gender: 'none',
    archetype: 'monster',
    assets: {
      master: 'public/assets/static/monster_static.png',
      idle: 'public/assets/monsters/shadow_wraith/soul - Idle.png',
      attack: 'public/assets/monsters/shadow_wraith/Soul - Attack.png',
      cast: 'public/assets/monsters/shadow_wraith/Soul - Attack.png',
      hit: 'public/assets/monsters/shadow_wraith/Soul - Hurt.png',
      death: 'public/assets/monsters/shadow_wraith/Soul - Dead.png',
      ultimate: 'public/assets/monsters/shadow_wraith/Soul - Attack.png',
      staticPortrait: 'public/assets/static/monster_static.png'
    },
    metrics: { frameWidth: 128, frameHeight: 128, scale: 2.2, originX: 0.5, originY: 0.85 }
  }
};

// Aliases for compatibility
CHARACTER_VISUAL_REGISTRY.paladin = CHARACTER_VISUAL_REGISTRY.human_fighter;
CHARACTER_VISUAL_REGISTRY.archmage = CHARACTER_VISUAL_REGISTRY.human_sorcerer;
CHARACTER_VISUAL_REGISTRY.duelist = CHARACTER_VISUAL_REGISTRY.human_fighter;
CHARACTER_VISUAL_REGISTRY.assassin = CHARACTER_VISUAL_REGISTRY.dark_elf_fighter;
CHARACTER_VISUAL_REGISTRY.spellsinger = CHARACTER_VISUAL_REGISTRY.dark_elf_mage;
CHARACTER_VISUAL_REGISTRY.death_knight = CHARACTER_VISUAL_REGISTRY.orc_fighter;

export function getCharacterVisualProfile(classId) {
  if (!classId || typeof classId !== 'string') return null;
  const normalized = classId.trim().toLowerCase();
  return CHARACTER_VISUAL_REGISTRY[normalized] || null;
}
