﻿/**
 * AnimationRegistry.js
 * 
 * Formal animation clip declarations for the 8 canonical classes and monster actors.
 * Direct implementation of Section 22.
 */

export const ANIMATION_REGISTRY = {
  // 1. Human Fighter
  anim_human_fighter: {
    IDLE: { key: 'IDLE', fileKey: 'idle', frameCount: 4, fps: 7, loop: true, frameWidth: 128, frameHeight: 128 },
    ATTACK: { key: 'ATTACK', fileKey: 'attack', frameCount: 5, fps: 11, loop: false, hitFrame: 3, frameWidth: 128, frameHeight: 128 },
    CAST: { key: 'CAST', fileKey: 'cast', frameCount: 4, fps: 10, loop: false, hitFrame: 2, frameWidth: 128, frameHeight: 128 },
    HIT: { key: 'HIT', fileKey: 'hit', frameCount: 2, fps: 10, loop: false, frameWidth: 128, frameHeight: 128 },
    DEAD: { key: 'DEAD', fileKey: 'death', frameCount: 6, fps: 8, loop: false, holdLastFrame: true, frameWidth: 128, frameHeight: 128 },
    ULTIMATE: { key: 'ULTIMATE', fileKey: 'ultimate', frameCount: 4, fps: 9, loop: false, hitFrame: 2, frameWidth: 128, frameHeight: 128 }
  },

  // 2. Human Sorcerer
  anim_human_sorcerer: {
    IDLE: { key: 'IDLE', fileKey: 'idle', frameCount: 7, fps: 8, loop: true, frameWidth: 128, frameHeight: 128 },
    ATTACK: { key: 'ATTACK', fileKey: 'attack', frameCount: 4, fps: 10, loop: false, hitFrame: 2, frameWidth: 128, frameHeight: 128 },
    CAST: { key: 'CAST', fileKey: 'cast', frameCount: 8, fps: 12, loop: false, releaseFrame: 4, frameWidth: 128, frameHeight: 128 },
    HIT: { key: 'HIT', fileKey: 'hit', frameCount: 3, fps: 12, loop: false, frameWidth: 128, frameHeight: 128 },
    DEAD: { key: 'DEAD', fileKey: 'death', frameCount: 6, fps: 8, loop: false, holdLastFrame: true, frameWidth: 128, frameHeight: 128 },
    ULTIMATE: { key: 'ULTIMATE', fileKey: 'ultimate', frameCount: 14, fps: 12, loop: false, releaseFrame: 7, frameWidth: 128, frameHeight: 128 }
  },

  // 3. Elf Fighter
  anim_elf_fighter: {
    IDLE: { key: 'IDLE', fileKey: 'idle', frameCount: 6, fps: 8, loop: true, frameWidth: 128, frameHeight: 128 },
    ATTACK: { key: 'ATTACK', fileKey: 'attack', frameCount: 4, fps: 12, loop: false, hitFrame: 2, frameWidth: 128, frameHeight: 128 },
    CAST: { key: 'CAST', fileKey: 'cast', frameCount: 3, fps: 11, loop: false, hitFrame: 1, frameWidth: 128, frameHeight: 128 },
    HIT: { key: 'HIT', fileKey: 'hit', frameCount: 3, fps: 12, loop: false, frameWidth: 128, frameHeight: 128 },
    DEAD: { key: 'DEAD', fileKey: 'death', frameCount: 3, fps: 8, loop: false, holdLastFrame: true, frameWidth: 128, frameHeight: 128 },
    ULTIMATE: { key: 'ULTIMATE', fileKey: 'ultimate', frameCount: 4, fps: 11, loop: false, hitFrame: 2, frameWidth: 128, frameHeight: 128 }
  },

  // 4. Elf Mage
  anim_elf_mage: {
    IDLE: { key: 'IDLE', fileKey: 'idle', frameCount: 8, fps: 8, loop: true, frameWidth: 128, frameHeight: 128 },
    ATTACK: { key: 'ATTACK', fileKey: 'attack', frameCount: 7, fps: 11, loop: false, hitFrame: 4, frameWidth: 128, frameHeight: 128 },
    CAST: { key: 'CAST', fileKey: 'cast', frameCount: 16, fps: 14, loop: false, releaseFrame: 8, frameWidth: 128, frameHeight: 128 },
    HIT: { key: 'HIT', fileKey: 'hit', frameCount: 4, fps: 12, loop: false, frameWidth: 128, frameHeight: 128 },
    DEAD: { key: 'DEAD', fileKey: 'death', frameCount: 4, fps: 8, loop: false, holdLastFrame: true, frameWidth: 128, frameHeight: 128 },
    ULTIMATE: { key: 'ULTIMATE', fileKey: 'ultimate', frameCount: 6, fps: 10, loop: false, releaseFrame: 3, frameWidth: 128, frameHeight: 128 }
  },

  // 5. Dark Elf Fighter
  anim_dark_elf_fighter: {
    IDLE: { key: 'IDLE', fileKey: 'idle', frameCount: 6, fps: 8, loop: true, frameWidth: 128, frameHeight: 128 },
    ATTACK: { key: 'ATTACK', fileKey: 'attack', frameCount: 5, fps: 13, loop: false, hitFrame: 3, frameWidth: 128, frameHeight: 128 },
    CAST: { key: 'CAST', fileKey: 'cast', frameCount: 3, fps: 12, loop: false, hitFrame: 2, frameWidth: 128, frameHeight: 128 },
    HIT: { key: 'HIT', fileKey: 'hit', frameCount: 2, fps: 12, loop: false, frameWidth: 128, frameHeight: 128 },
    DEAD: { key: 'DEAD', fileKey: 'death', frameCount: 4, fps: 8, loop: false, holdLastFrame: true, frameWidth: 128, frameHeight: 128 },
    ULTIMATE: { key: 'ULTIMATE', fileKey: 'ultimate', frameCount: 4, fps: 12, loop: false, hitFrame: 2, frameWidth: 128, frameHeight: 128 }
  },

  // 6. Dark Elf Mage
  anim_dark_elf_mage: {
    IDLE: { key: 'IDLE', fileKey: 'idle', frameCount: 7, fps: 8, loop: true, frameWidth: 128, frameHeight: 128 },
    ATTACK: { key: 'ATTACK', fileKey: 'attack', frameCount: 4, fps: 10, loop: false, hitFrame: 2, frameWidth: 128, frameHeight: 128 },
    CAST: { key: 'CAST', fileKey: 'cast', frameCount: 7, fps: 11, loop: false, releaseFrame: 4, frameWidth: 128, frameHeight: 128 },
    HIT: { key: 'HIT', fileKey: 'hit', frameCount: 3, fps: 12, loop: false, frameWidth: 128, frameHeight: 128 },
    DEAD: { key: 'DEAD', fileKey: 'death', frameCount: 5, fps: 8, loop: false, holdLastFrame: true, frameWidth: 128, frameHeight: 128 },
    ULTIMATE: { key: 'ULTIMATE', fileKey: 'ultimate', frameCount: 13, fps: 12, loop: false, releaseFrame: 7, frameWidth: 128, frameHeight: 128 }
  },

  // 7. Orc Fighter
  anim_orc_fighter: {
    IDLE: { key: 'IDLE', fileKey: 'idle', frameCount: 4, fps: 7, loop: true, frameWidth: 128, frameHeight: 128 },
    ATTACK: { key: 'ATTACK', fileKey: 'attack', frameCount: 5, fps: 10, loop: false, hitFrame: 3, frameWidth: 128, frameHeight: 128 },
    CAST: { key: 'CAST', fileKey: 'cast', frameCount: 4, fps: 9, loop: false, hitFrame: 2, frameWidth: 128, frameHeight: 128 },
    HIT: { key: 'HIT', fileKey: 'hit', frameCount: 2, fps: 10, loop: false, frameWidth: 128, frameHeight: 128 },
    DEAD: { key: 'DEAD', fileKey: 'death', frameCount: 6, fps: 8, loop: false, holdLastFrame: true, frameWidth: 128, frameHeight: 128 },
    ULTIMATE: { key: 'ULTIMATE', fileKey: 'ultimate', frameCount: 4, fps: 9, loop: false, hitFrame: 2, frameWidth: 128, frameHeight: 128 }
  },

  // 8. Orc Shaman
  anim_orc_shaman: {
    IDLE: { key: 'IDLE', fileKey: 'idle', frameCount: 6, fps: 7, loop: true, frameWidth: 128, frameHeight: 128 },
    ATTACK: { key: 'ATTACK', fileKey: 'attack', frameCount: 9, fps: 11, loop: false, hitFrame: 5, frameWidth: 128, frameHeight: 128 },
    CAST: { key: 'CAST', fileKey: 'cast', frameCount: 10, fps: 11, loop: false, releaseFrame: 6, frameWidth: 128, frameHeight: 128 },
    HIT: { key: 'HIT', fileKey: 'hit', frameCount: 3, fps: 12, loop: false, frameWidth: 128, frameHeight: 128 },
    DEAD: { key: 'DEAD', fileKey: 'death', frameCount: 4, fps: 8, loop: false, holdLastFrame: true, frameWidth: 128, frameHeight: 128 },
    ULTIMATE: { key: 'ULTIMATE', fileKey: 'ultimate', frameCount: 7, fps: 10, loop: false, releaseFrame: 4, frameWidth: 128, frameHeight: 128 }
  },

  // 9. Monster: Shadow Wraith
  anim_shadow_wraith: {
    IDLE: { key: 'IDLE', fileKey: 'idle', frameCount: 6, fps: 7, loop: true, frameWidth: 128, frameHeight: 128 },
    ATTACK: { key: 'ATTACK', fileKey: 'attack', frameCount: 5, fps: 10, loop: false, hitFrame: 3, frameWidth: 128, frameHeight: 128 },
    CAST: { key: 'CAST', fileKey: 'cast', frameCount: 5, fps: 10, loop: false, releaseFrame: 3, frameWidth: 128, frameHeight: 128 },
    HIT: { key: 'HIT', fileKey: 'hit', frameCount: 3, fps: 12, loop: false, frameWidth: 128, frameHeight: 128 },
    DEAD: { key: 'DEAD', fileKey: 'death', frameCount: 4, fps: 8, loop: false, holdLastFrame: true, frameWidth: 128, frameHeight: 128 }
  }
};

// Aliases for backwards compatibility with V1 tests
ANIMATION_REGISTRY.mage_fire = ANIMATION_REGISTRY.anim_human_sorcerer;
ANIMATION_REGISTRY.knight_holy = ANIMATION_REGISTRY.anim_human_fighter;
ANIMATION_REGISTRY.shinobi_shadow = ANIMATION_REGISTRY.anim_dark_elf_fighter;
ANIMATION_REGISTRY.mage_lightning = ANIMATION_REGISTRY.anim_dark_elf_mage;
ANIMATION_REGISTRY.vampire_blood = ANIMATION_REGISTRY.anim_orc_fighter;
ANIMATION_REGISTRY.undead_wraith = ANIMATION_REGISTRY.anim_shadow_wraith;

export function getAnimationClip(animationSet, stateName) {
  const set = ANIMATION_REGISTRY[animationSet];
  if (!set) return null;
  return set[stateName] || null;
}
